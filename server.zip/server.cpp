#include "server.h"
#include "ui_server.h"
#include <QTcpServer>
#include <QTcpSocket>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QDateTime>
#include <QFile>

int currentsize;

server::server(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::server)
{
    ui->setupUi(this);
    tcpServer = new QTcpServer();

    ui->listWidget->clear();
    ui->listWidget->insertItem(0,tr("当前无在线用户"));
    for(int i = 0; i < M; i++)
    {
        tcpSocket[i]=new QTcpSocket();
    }
    tcpServer->listen(QHostAddress::Any,8888);

    //init
    db = QSqlDatabase::addDatabase("QSQLITE");

    //判断是否建立了用户表
    db.setDatabaseName("./people.db");
    db.open();
    QSqlQuery sqlquery;
    sqlquery.exec("CREATE TABLE if not exists people(id INTEGER NOT NULL UNIQUE,name TEXT NOT NULL UNIQUE,password TEXT NOT NULL,question TEXT NOT NULL,answer TEXT NOT NULL,birthyear TEXT,sex TEXT,ip TEXT,islogin INTEGER NOT NULL,PRIMARY KEY(id AUTOINCREMENT))");
    QSqlQuery sqlquery2;
    sqlquery2.exec("CREATE TABLE if not exists friend(name1 TEXT NOT NULL,name2 TEXT NOT NULL,PRIMARY KEY(name1,name2))");
    db.close();

    connect(tcpServer,&QTcpServer::newConnection,[=](){

        tcpSocket[0] = tcpServer->nextPendingConnection();
        currentsize++;
        QString ip = tcpSocket[0]->peerAddress().toString().
                section(":",3,3);
        int port = tcpSocket[0]->peerPort();
        //预留currentsize以用作多用户同时连接所用
        QString str = QString("[%1:%2]").arg(ip).arg(port);
        qDebug() << str ;

        connect(tcpSocket[0],&QTcpSocket::readyRead,[=](){
            //读取缓冲区数据
            QByteArray buffer = tcpSocket[0]->readAll();

            if("login" == QString(buffer).section("##",0,0))
            {//登陆
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                sqlquery.exec();
                if(!sqlquery.next())
                {//未查找到该用户
                    tcpSocket[0]->write(QString("login error##no_user").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
                else
                {//用户存在
                    int id = sqlquery.value(0).toInt();
                    QString pwd = sqlquery.value(2).toString();
                    if(pwd == QString(buffer).section("##",2,2))
                    {//登录成功
                        tcpSocket[0]->write(QString("login successed##%1").arg(id).toUtf8());
                        sqlquery.prepare("update people set ip=:ip, islogin=1 where name = :name");
                        sqlquery.bindValue(":ip",ip);
                        sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                        sqlquery.exec();
                        tcpSocket[0]->flush();

                        //更新服务器界面
                        ui->listWidget->clear();
                        sqlquery.prepare("select * from people where islogin = 1");
                        sqlquery.exec();
                        if(sqlquery.next())
                        {
                            QString userid = sqlquery.value(0).toString();
                            QString username = sqlquery.value(1).toString();
                            QString userip = sqlquery.value(7).toString();
                            //qDebug()<<userid;
                            ui->listWidget->insertItem(0,"用户ID："+userid+",用户昵称:"+username+",用户IP:"+userip);
                            int rownum = 1;
                            while (sqlquery.next())
                            {
                                QString userid = sqlquery.value(0).toString();
                                QString username = sqlquery.value(1).toString();
                                QString userip = sqlquery.value(7).toString();
                                ui->listWidget->insertItem(rownum,"用户ID："+userid+",用户昵称:"+username+",用户IP:"+userip);
                                rownum++;
                            }
                        }
                        else
                        {
                            ui->listWidget->clear();
                            ui->listWidget->insertItem(0,tr("当前无在线用户"));
                        }
                    }
                    else
                    {//密码错误
                        tcpSocket[0]->write(QString("login error##errpwd").toUtf8());
                        tcpSocket[0]->flush();
                        db.close();
                    }
                }
            }
            else if("register" == QString(buffer).section("##",0,0))
            {//注册环节
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                //注册用户的时候需要进行判重
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                sqlquery.exec();
                if(!sqlquery.next())
                {//可以新建
                    sqlquery.clear();
                    sqlquery.prepare("insert into people values (null,:name,:password,:question,:answer,:birthyear,:sex,null,0)");
                    sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                    sqlquery.bindValue(":password",QString(buffer).section("##",2,2));
                    sqlquery.bindValue(":question",QString(buffer).section("##",3,3));
                    sqlquery.bindValue(":answer",QString(buffer).section("##",4,4));
                    sqlquery.bindValue(":birthyear",QString(buffer).section("##",5,5));
                    sqlquery.bindValue(":sex",QString(buffer).section("##",6,6));

                    sqlquery.exec();

                    sqlquery.clear();
                    sqlquery.prepare("select * from people where name = :name");
                    sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                    sqlquery.exec();//获得新建的用户的id
                    sqlquery.next();
                    int newid = sqlquery.value(0).toInt();
                    sqlquery.exec("create table if not exists friend__" + QString::number(newid) +"(id INTEGER unique, name TEXT,sendmassage INTEGER,sendfile INTEGER)");

                    tcpSocket[0]->write(QString("register successed").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }

                else
                {//有重名
                     tcpSocket[0]->write(QString("register error##same_name").toUtf8());
                     tcpSocket[0]->flush();
                     db.close();
                }
            }

            else if("find"==QString(buffer).section("##",0,0))
            {
//                printf("find\n");
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                sqlquery.exec();
                if(!sqlquery.next())
                {
                    tcpSocket[0]->write(QString("find_error##no_user").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
                else
                {
                    QString a=sqlquery.value("question").toString();
                    QString b=sqlquery.value("answer").toString();
                    QString c=sqlquery.value("password").toString();
                    QString d=a+"##"+b+"##"+c;
                    tcpSocket[0]->write(d.toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
            }
            else if("myself"==QString(buffer).section("##",0,0))
            {
                printf("myself\n");
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
                sqlquery.exec();
                if(!sqlquery.next())
                {
                    tcpSocket[0]->write(QString("find_error##no_user").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();

                }
                else
                {
                    QString a=sqlquery.value("question").toString();
                    QString b=sqlquery.value("birthyear").toString();
                    QString c=sqlquery.value("sex").toString();
                    QString d=a+"##"+b+"##"+c;
                    tcpSocket[0]->write(d.toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
            }
//            else if("avatar"==QString(buffer).section("##",0,0))
//            {
                

//                QTcpServer server;
//                server.listen(QHostAddress::Any, 1234); // 监听所有IP地址的1234端口
            
//                while (true)
//                {
//                    // 等待客户端连接
//                    if (server.waitForNewConnection())
//                    {
//                        // 获取客户端连接
//                        QTcpSocket *clientSocket = server.nextPendingConnection();
            
//                        // 接收文件名和文件内容
//                        QByteArray imageData = clientSocket->readAll();
            
//                        QDataStream dataStream(&imageData, QIODevice::ReadOnly);
//                        QByteArray fileNameData;
//                        dataStream >> fileNameData;
            
//                        QString fileName = QString::fromUtf8(fileNameData);
//                        QByteArray fileData;
//                        dataStream >> fileData;
            
//                        // 保存文件
//                        QFile file(fileName);
//                        if (file.open(QIODevice::WriteOnly)) {
//                            file.write(fileData);
//                            file.close();
//                        }
            
//                        clientSocket->disconnectFromHost();
//                        clientSocket->deleteLater();
//                    }
//                }

//                printf("avatar\n");
//                db.setDatabaseName("./people.db");
//                db.open();
//                QSqlQuery sqlquery;
//                sqlquery.prepare("select * from people where name = :name");
//                sqlquery.bindValue(":name",QString(buffer).section("##",1,1));
//                sqlquery.exec();
//                if(!sqlquery.next())
//                {
//                    tcpSocket[0]->write(QString("find_error##no_user").toUtf8());
//                    tcpSocket[0]->flush();
//                    db.close();

//                }
//                else
//                {
//                    QString a=sqlquery.value("question").toString();
//                    QString b=sqlquery.value("birthyear").toString();
//                    QString c=sqlquery.value("sex").toString();
//                    QString d=a+"##"+b+"##"+c;
//                    tcpSocket[0]->write(d.toUtf8());
//                    tcpSocket[0]->flush();
//                    db.close();
//                }
//            }
            else if("wantsendmessage" == QString(buffer).section("##",0,0))
            {//想发信息，校验有没有这个人
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",2,2));
                sqlquery.exec();
                if(sqlquery.next())
                {//有这个人在，可以发消息
                    int otherid = sqlquery.value(0).toInt();
                    tcpSocket[0]->write(QString("wantsendmessage_ok##%1").
                                        arg(otherid).toUtf8());
                    tcpSocket[0]->flush();

                    //发消息前把数据库准备好
                    int thisid = QString(buffer).section("##",1,1).toInt();
                    if(thisid < otherid)
                    {
                        sqlquery.exec("CREATE TABLE if not exists chat__" +
                                      QString::number(thisid) + "__" +
                                      QString::number(otherid) +
      "(time datetime NOT NULL UNIQUE,id INTEGER,message TEXT, PRIMARY KEY(time))");
                    }
                    else
                    {
                        sqlquery.exec("CREATE TABLE if not exists chat__" +
                                      QString::number(otherid) + "__" +
                                      QString::number(thisid) +
      "(time datetime NOT NULL UNIQUE,id INTEGER,message TEXT, PRIMARY KEY(time))");
                    }


                    db.close();
                }
                else
                {//查无此人，无法对话
                    tcpSocket[0]->write(QString("wantsendmessage_error").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
            }

            else if("chat_history" == QString(buffer).section("##",0,0))
            {//idone是发信息的，idtwo是收信息的，所以one已经阅览了two的所有消息
                int idone = QString(buffer).section("##",1,1).toInt();
                int idtwo = QString(buffer).section("##",2,2).toInt();
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                QString sqlstring = "";
                if(idone < idtwo)
                {
                    sqlstring = "select * from chat__" +
                            QString::number(idone) + "__" +
                            QString::number(idtwo) + " order by time desc limit 20";
                }
                else
                {
                    sqlstring = "select * from chat__" +
                            QString::number(idtwo) + "__" +
                            QString::number(idone) + " order by time desc limit 20";
                }
                qDebug()<<sqlstring;
                sqlquery.exec(sqlstring);

                if(sqlquery.next())
                {
                    QString history = "##" + sqlquery.value(0).toDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz")+ "##" + sqlquery.value(1).toString()+ "##" + sqlquery.value(2).toString();
                    int hisnum = 1;
                    while(sqlquery.next())
                    {
                        hisnum++;
                        QDateTime time = sqlquery.value(0).toDateTime();
                        QString timestr = time.toString("yyyy-MM-dd hh:mm:ss.zzz");
                        history = history + "##" + timestr;//时间
                        history = history + "##" + sqlquery.value(1).toString();//谁发的
                        history = history + "##" + sqlquery.value(2).toString();//内容
                    }
                    history = "chat_history_ok##" + QString::number(hisnum) + history;
                    tcpSocket[0]->write(history.toUtf8());
                    tcpSocket[0]->flush();

                    QString sqlstring = "update friend__" + QString::number(idone) + " set sendmassage = 0 where id = :id";
                    db.setDatabaseName("./people.db");
                    db.open();
                    QSqlQuery sqlquery;
                    sqlquery.prepare(sqlstring);
                    sqlquery.bindValue(":id", idtwo);
                    sqlquery.exec();
                    db.close();
                }
                else
                {//无历史记录
                    tcpSocket[0]->write(QString("chat_history_error").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
            }
            else if("chat_send" == QString(buffer).section("##",0,0))
            {//one发消息的，two收消息的
                QDateTime nowstr = QDateTime::fromString(QString(buffer).
                                                         section("##",1,1),
                                                         "yyyy-MM-dd hh:mm:ss.zzz");
                int idone = QString(buffer).section("##",2,2).toInt();
                int idtwo = QString(buffer).section("##",3,3).toInt();
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                QString sqlstring = "";
                if(idone < idtwo)
                {
                    sqlstring = "insert into chat__" +
                            QString::number(idone) +
                            "__" +
                            QString::number(idtwo) +
                            " values(:time,:id,:message)";
                }
                else
                {
                    sqlstring = "insert into chat__" +
                            QString::number(idtwo) +
                            "__" +
                            QString::number(idone) +
                            " values(:time,:id,:message)";
                }
                qDebug()<<sqlstring;
                sqlquery.prepare(sqlstring);
                sqlquery.bindValue(":time",nowstr);
                sqlquery.bindValue(":id",idone);
                sqlquery.bindValue(":message",QString(buffer).
                                   section("##",4,4));
                sqlquery.exec();

                sqlstring = "update friend__" + QString::number(idtwo) +
                        " set sendmassage = 1 where id = :id";
                db.setDatabaseName("./people.db");
                db.open();
                sqlquery.clear();
                sqlquery.prepare(sqlstring);
                sqlquery.bindValue(":id", idone);
                sqlquery.exec();
                db.close();
            }
            else if("logout" == QString(buffer).section("##",0,0))
            {
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("update people set islogin=0 where id = :id");
                sqlquery.bindValue(":id",QString(buffer).section("##",1,1));
                sqlquery.exec();

                //更新服务器界面
                ui->listWidget->clear();
                sqlquery.prepare("select * from people where islogin = 1");
                sqlquery.exec();
                if(sqlquery.next())
                {
                    QString userid = sqlquery.value(0).toString();
                    QString username = sqlquery.value(1).toString();
                    QString userip = sqlquery.value(7).toString();
                    //qDebug()<<userid;
                    ui->listWidget->insertItem(0,"用户ID："+
                                               userid+
                                               ",用户昵称:"+
                                               username+
                                               ",用户IP:"+
                                               userip);
                    int rownum = 1;
                    while (sqlquery.next())
                    {
                        QString userid = sqlquery.value(0).toString();
                        QString username = sqlquery.value(1).toString();
                        QString userip = sqlquery.value(7).toString();
                        ui->listWidget->insertItem(rownum,"用户ID："+userid+",用户昵称:"+username+",用户IP:"+userip);
                        rownum++;
                    }
                }
                else
                {
                    ui->listWidget->clear();
                    ui->listWidget->insertItem(0,tr("当前无在线用户"));
                }
            }
            else if("getfriendlist" == QString(buffer).section("##",0,0))
            {
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.exec("select * from friend__" +
                              QString(buffer).section("##",1,1) + " desc");

                if(sqlquery.next())
                {
                    QList <QString> friendlist;
                    QList <QString> friendsendfilelist;
                    QList <QString> friendsendmassagelist;
                    friendlist.append(sqlquery.value(1).toString());

                    int sendmassagenum = 0;
                    if(sqlquery.value(2).toString() == '1')
                    {
                        sendmassagenum++;
                    }
                    friendsendmassagelist.append(sqlquery.value(2).toString());
                    int sendfilenum = 0;
                    if(sqlquery.value(3).toString() == '1')
                    {
                        sendfilenum++;
                    }
                    friendsendfilelist.append(sqlquery.value(3).toString());

                    QString friends = "";
                    while(sqlquery.next())
                    {
                        friendlist.append(sqlquery.value(1).toString());
                        if(sqlquery.value(2).toString() == '1')
                        {
                            sendmassagenum++;
                        }
                        friendsendmassagelist.append(sqlquery.value(2).toString());
                        if(sqlquery.value(3).toString() == '1')
                        {
                            sendfilenum++;
                        }
                        friendsendfilelist.append(sqlquery.value(3).toString());
                    }

                    int onlinefriendnum = 0;
                    for( int i = 0; i < friendlist.length(); i++)
                    {
                        sqlquery.prepare("select * from people where name = :name");
                        sqlquery.bindValue(":name",friendlist.at(i));
                        sqlquery.exec();
                        sqlquery.next();
                        QString peopleip = sqlquery.value(7).toString();
                        if(sqlquery.value(4).toInt() == 1)
                        {
                            onlinefriendnum++;
                            friends = "##" +
                                    friendlist.at(i) +
                                    "##1##" + peopleip +
                                    "##"+friendsendmassagelist.at(i)+
                                    "##"+ friendsendfilelist.at(i)+
                                    friends;
                        }
                        else
                        {
                            friends = "##" +
                                    friendlist.at(i) +
                                    "##0##" + peopleip +
                                    "##"+friendsendmassagelist.at(i)+
                                    "##"+ friendsendfilelist.at(i)+
                                    friends;
                        }
                    }
                    friends = "getfriendlist_ok##" +
                            QString::number(friendlist.length()) +
                            "##"+QString::number(onlinefriendnum)+
                            "##"+QString::number(sendmassagenum)+
                            "##"+QString::number(sendfilenum)+
                            friends;
                    qDebug()<<friends;
                    tcpSocket[0]->write(friends.toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
                else
                {//无朋友
                    tcpSocket[0]->write(QString("getfriendlist_error").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
            }
            else if("add_friend" == QString(buffer).section("##",0,0))
            {
                int whowantadd_id = QString(buffer).section("##",1,1).toInt();
                QString friend_name = QString(buffer).section("##",2,2);
                QString friend_ip = QString(buffer).section("##",3,3);
                int friend_port = QString(buffer).section("##",4,4).toInt();
                QString whowantadd_name = QString(buffer).section("##",5,5);

                qDebug() << whowantadd_id << friend_name
                         << friend_ip << friend_port;

                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",friend_name);
                sqlquery.exec();

                if(!sqlquery.next())
                {//没这人
                    qDebug() <<"e";
                    tcpSocket[0]->write(QString("add_friend_error").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
                else
                {
                    QSqlQuery sqlquery2;
                    sqlquery2.prepare("insert into friend values(:name1,:name2)");
                    sqlquery2.bindValue(":name1",whowantadd_name);
                    sqlquery2.bindValue(":name2",friend_name);
                    sqlquery2.exec();

                    db.close();
                }
            }
            else if("check" == QString(buffer).section("##",0,0))
            {
                db.setDatabaseName("./people.db");
                db.open();
                QString name2 = QString(buffer).section("##",1,1);
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from friend where name2 = :name");
                sqlquery.bindValue(":name",name2);
                sqlquery.exec();

                if(!sqlquery.next())
                {//没check
                    qDebug() <<"e";
                    tcpSocket[0]->write(QString("no_check").toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
                else
                {
                    QString checkone="check_success##"+sqlquery.value(0).toString();
                    tcpSocket[0]->write(checkone.toUtf8());
                    tcpSocket[0]->flush();
                    db.close();
                }
            }
            else if ("add_friend_accept" == QString(buffer).section("##",0,0))
            {
                bool testA,testB;
                testA = false;
                testB = false;

                qDebug()<<"enter";
                QString user_name = QString(buffer).section("##",1,1);
                QString friend_name = QString(buffer).section("##",2,2);
                qDebug()<<user_name<<friend_name;

                db.setDatabaseName("./people.db");
                db.open();

                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",friend_name);
                sqlquery.exec();

                int friend_id;
                if (sqlquery.next())
                {
                    friend_id = sqlquery.value(0).toInt();
                    qDebug() <<friend_id;
                    testA = true;
                }

                sqlquery.clear();
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",user_name);
                sqlquery.exec();

                int user_id;
                if (sqlquery.next())
                {
                    user_id = sqlquery.value(0).toInt();
                    qDebug() <<user_id;
                    testB = true;
                }

                if (testA && testB)
                {
                    sqlquery.clear();
                    QString sqlstring = "insert into friend__" +
                            QString::number(user_id) +
                            " values(:id,:name,0,0)";
                    qDebug()<<sqlstring;
                    sqlquery.prepare(sqlstring);
                    sqlquery.bindValue(":id",friend_id);
                    sqlquery.bindValue(":name",friend_name);
                    sqlquery.exec();
                    qDebug()<<sqlquery.lastError();

                    // 双向添加
                    sqlquery.clear();
                    QString sqlstring2 = "insert into friend__" +
                            QString::number(friend_id) +
                            " values(:id,:name,0,0)";
                    qDebug()<<sqlstring2;
                    sqlquery.prepare(sqlstring2);
                    sqlquery.bindValue(":id",user_id);
                    sqlquery.bindValue(":name",user_name);
                    sqlquery.exec();
                    qDebug()<<sqlquery.lastError();

                    // 双边清除验证
                    QSqlQuery sqlquery_1;
                    sqlquery_1.prepare("delete from friend where name1 = :name1 and name2 = :name2");
                    sqlquery_1.bindValue(":name1",user_name);
                    sqlquery_1.bindValue(":name2",friend_name);

                    QSqlQuery sqlquery_2;
                    sqlquery_2.prepare("delete from friend where name1 = :name1 and name2 = :name2");
                    sqlquery_2.bindValue(":name1",friend_name);
                    sqlquery_2.bindValue(":name2",user_name);

                    if (sqlquery_1.exec() && sqlquery_2.exec())
                    {
                        ;
                    }
                }


                db.close();

            }
            else if("delete_friend" == QString(buffer).section("##",0,0))
            {
                int whowantdelete_id = QString(buffer).section("##",1,1).toInt();
                QString friend_name = QString(buffer).section("##",2,2);

                db.setDatabaseName("./people.db");
                db.open();

                QSqlQuery sqlquery;
                sqlquery.prepare("delete from friend__"+QString::number(whowantdelete_id)+" where name = :name");
                sqlquery.bindValue(":name",friend_name);

                qDebug()<<friend_name<<whowantdelete_id;

                QSqlQuery sqlquery2;
                sqlquery2.prepare("select * from people where name = :name");
                sqlquery2.bindValue(":name",friend_name);
                sqlquery2.exec();
                int friend_id;
                if (sqlquery2.next())
                {
                    friend_id = sqlquery2.value(0).toInt();
                    qDebug() <<friend_id;
                }

                QSqlQuery sqlquery3;
                sqlquery3.prepare("select * from people where id = :id");
                sqlquery3.bindValue(":id",whowantdelete_id);
                sqlquery3.exec();
                QString whowantdelete_name;
                if (sqlquery3.next())
                {
                    whowantdelete_name = sqlquery3.value(1).toString();
                    qDebug() <<whowantdelete_name;
                }

                // 双向删除
                QSqlQuery sqlquery4;
                sqlquery4.prepare("delete from friend__"+QString::number(friend_id)+" where name = :name");
                sqlquery4.bindValue(":name",whowantdelete_name);

                qDebug()<<friend_id<<whowantdelete_name;

                sqlquery.exec();
                qDebug()<<"get1";

                sqlquery4.exec();
                qDebug()<<"get4";

                tcpSocket[0]->write(QString("delete_friend_ok").toUtf8());
                tcpSocket[0]->flush();
                db.close();

            }
            else if("want_send_file" == QString(buffer).section("##",0,0))
            {//1给2发,1是id,2是name;在2的表中显示1的信息
                int userid = QString(buffer).section("##",1,1).toInt();
                qDebug()<<buffer;
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",2,2));
                sqlquery.exec();
                sqlquery.next();
                int otheruserid = sqlquery.value(0).toInt();

                QString sqlstring = "update friend__" + QString::number(otheruserid) + " set sendfile = 1 where id = :id";
                sqlquery.prepare(sqlstring);
                sqlquery.bindValue(":id",userid);
                sqlquery.exec();
            }
            else if("send_file_ok" == QString(buffer).section("##",0,0))
            {//1给2发,1是id,2是name;在2的表中显示1的信息
                int userid = QString(buffer).section("##",1,1).toInt();
                qDebug()<<buffer;
                QString sqlstring = "update friend__" + QString::number(userid) + " set sendfile = 0 where name = :name";
                qDebug()<<sqlstring;
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare(sqlstring);
                sqlquery.bindValue(":name", QString(buffer).section("##",2,2));
                sqlquery.exec();
            }
            else if("send_file_miss" == QString(buffer).section("##",0,0))
            {
                int userid = QString(buffer).section("##",1,1).toInt();
                qDebug()<<buffer;
                db.setDatabaseName("./people.db");
                db.open();
                QSqlQuery sqlquery;
                sqlquery.prepare("select * from people where name = :name");
                sqlquery.bindValue(":name",QString(buffer).section("##",2,2));
                sqlquery.exec();
                sqlquery.next();
                int otheruserid = sqlquery.value(0).toInt();

                QString sqlstring = "update friend__" + QString::number(otheruserid) + " set sendfile = 0 where id = :id";
                sqlquery.prepare(sqlstring);
                sqlquery.bindValue(":id",userid);
                sqlquery.exec();
            }
        });
    });
}

server::~server()
{
    tcpServer->close();
    tcpServer->deleteLater();
    delete ui;
}
