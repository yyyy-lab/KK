#include "avatar.h"
#include "ui_avatar.h"
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>
#include <QDebug>
#include <QGraphicsDropShadowEffect>
#include <QBuffer>
#include <userinfo.h>
#include "homenew.h"

extern userinfo user;
extern QString hostip;
extern int hosthost;

avatar::avatar(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::avatar)
{
    ui->setupUi(this);
    tcpSocket = new QTcpSocket();

}

avatar::~avatar()
{
    delete ui;
}

void avatar::recvMsg(){

}
void avatar::on_pushButton_clicked()//点击选择文件
{
    QString fileName = QFileDialog::getOpenFileName(this, tr("Open File"),
                 "/home"
                 );//tr("Images (*.png *.xpm *.jpg *.txt *.gz)")
    //fileName = QFileDialog::getOpenFileName(this);
    qDebug() << "fileName:" << fileName;
    ui->lineEdit->setText(fileName);
    ui->lineEdit->setCursorPosition(0);//把光标移到左侧
}


void avatar::on_pushButton_2_clicked()
{
//    QString fileName = ui->lineEdit->text();
//    qDebug()<<fileName;

//    if(fileName != "")
//    {
//        QFile file(fileName);
//        file.open(QIODevice::ReadOnly);
//        QByteArray fileData = file.readAll();
//        QByteArray imageData;
//        QDataStream dataStream(&imageData, QIODevice::WriteOnly);
//        dataStream << fileName.toUtf8();
//        dataStream << fileData;

//        tcpSocket->write(imageData);
//        tcpSocket->waitForBytesWritten();

//        file.close();
        
//        if(!tcpSocket->waitForConnected(30000))
//        {
//            QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
//            this->close();
//            user.islogin = false;
//        }
//        else
//        {//服务器连接成功
//            QString loginmessage = QString("myself##%1##%2").arg(user.name).arg(QString(t));
//            tcpSocket->write(loginmessage.toUtf8());
//            tcpSocket->flush();
//            QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
//            int port = tcpSocket->peerPort();
//            QString str = QString("[%1:%2]").arg(ip).arg(port);
//            qDebug() << str;

//            // 当有数据可读时
//            connect(tcpSocket,&QTcpSocket::readyRead,[=](){
//                QByteArray buffer = tcpSocket->readAll();
////                ui->myquestionLineEdit->setText(QString(buffer).section("##",0,0));
////                ui->mybirthyearLineEdit->setText(QString(buffer).section("##",1,1));
////                ui->mysexLineEdit->setText(QString(buffer).section("##",2,2));

//            });
//        }
        
//        this->close();
//    }
//    else
//    {
//            QMessageBox::warning(this, "Warning!", "文件为空", QMessageBox::Yes);
//    }
}

void avatar::on_cancelButton_clicked()
{
    this->close();
}

void avatar::mousePressEvent(QMouseEvent *event)
{
   if(event->button() == Qt::LeftButton)
   {
       m_point = event->globalPos() - pos(); //计算移动量
       event->accept();
   }
}

//鼠标移动
void avatar::mouseMoveEvent(QMouseEvent *event)
{
    if(event->buttons() & Qt::LeftButton)
    {
        move(event->globalPos() - m_point);
        event->accept();
    }
}


