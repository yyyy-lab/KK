#include "userinfo.h"

userinfo::userinfo()
{
    this->islogin = false;
    this->ip = "10.171.213.244";
    this->port = 8888;
}

userinfo user;
