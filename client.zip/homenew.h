#ifndef HOMENEW_H
#define HOMENEW_H

#include <QDialog>
#include <QTcpSocket>

namespace Ui {
class homenew;
}

class homenew : public QDialog
{
    Q_OBJECT

public:
    explicit homenew(QWidget *parent = nullptr);
    ~homenew();

private slots:
    void on_pushButton_friendlist_clicked();

    void on_pushButton_avatar_clicked();

    void on_pushButton_grzy_clicked();
    void on_pushButton_seal_clicked();

protected:
    void closeEvent(QCloseEvent *event);


private:
    Ui::homenew *ui;
    QTcpSocket *tcpSocket;
};

#endif // HOMENEW_H
