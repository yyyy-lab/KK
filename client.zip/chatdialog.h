#ifndef CHATDIALOG_H
#define CHATDIALOG_H

#include <QWidget>
#include <QTcpSocket>
#include <QMessageBox>
#include <QTimer>
#include <QCloseEvent>
#include "friendlist.h"
#include <QColor>

namespace Ui {
class chatdialog;
}

class chatdialog : public QWidget
{
    Q_OBJECT

public:
    explicit chatdialog(QWidget *parent = nullptr);
    ~chatdialog();
    QTimer *timer;
private slots:
    void on_pushButton_clicked();
    void getchathistory();
    void on_pushButton_send_clicked();

    void on_pushButton_receivefile_clicked();

    void on_pushButton_sendfile_clicked();
    void receive_shake();
    void on_pushButton_color_clicked();

    void on_firetrans_clicked();
    void onBtnSendFile();
    void onBtnSendImage();

    void on_pushButton_shake_clicked();

    void on_pushButton_screenshot_clicked();

protected:
    void closeEvent(QCloseEvent *event);
private:
    Ui::chatdialog *ui;
    QColor color;
    QTcpSocket *tcpSocket;
    QString m_uuid;

signals:
    //发送文件信号
    void sendFile(const QString &uuid, const QString &fileName);
    //发送图片信号
    void sendImage(const QString &uuid, const QString &imagePath);
};

#endif // CHATDIALOG_H
