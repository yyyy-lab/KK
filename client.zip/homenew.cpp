#include "homenew.h"
#include "ui_homenew.h"
#include "friendlist.h"
#include "myself.h"
#include "userinfo.h"
#include <QMessageBox>
#include "QProcess"

extern QString hostip;
extern int hosthost;
extern userinfo user;

homenew::homenew(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::homenew)
{
    ui->setupUi(this);
}

homenew::~homenew()
{
    delete ui;
}

void homenew::on_pushButton_friendlist_clicked()
{
    this->hide();
    friendlist *fl = new friendlist();
    fl->show();
}

void homenew::on_pushButton_grzy_clicked()
{
    myself *pic =new myself();
    pic->show();
}
// 窗口关闭事件处理函数
void homenew::closeEvent(QCloseEvent *event)
{
    // 创建与服务器的TCP套接字并连接
    tcpSocket = new QTcpSocket();
    tcpSocket->abort();  // 取消已有连接
    tcpSocket->connectToHost(hostip, hosthost);  // 连接服务器
    if (!tcpSocket->waitForConnected(30000))
    {
        // 连接失败，直接关闭窗口
        this->close();
        user.islogin = false;
    }
    else
    {
        // 连接成功，向服务器发送登出信息
        QString message = QString("logout##%1").arg(user.id);
        tcpSocket->write(message.toUtf8());
        tcpSocket->flush();
        QMessageBox::warning(this, "Success", "下线成功", QMessageBox::Yes);
    }
}


void homenew::on_pushButton_avatar_clicked()
{
//    tcpSocket->abort();//取消已有链接
//    tcpSocket->connectToHost(hostip, hosthost);//链接服务器

//    if(!tcpSocket->waitForConnected(30000))
//    {
//        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
//        this->close();
//        user.islogin = false;
//    }
//    else
//    {//服务器连接成功
//        QString loginmessage = QString("avatar##%1").arg(user.name);
//        tcpSocket->write(loginmessage.toUtf8());
//        tcpSocket->flush();
//        QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
//        int port = tcpSocket->peerPort();
//        QString str = QString("[%1:%2]").arg(ip).arg(port);
//        qDebug() << str;

//        // 当有数据可读时
//        connect(tcpSocket,&QTcpSocket::readyRead,[=](){
//            QByteArray buffer = tcpSocket->readAll();
//            ui->myquestionLineEdit->setText(QString(buffer).section("##",0,0));
//            ui->mybirthyearLineEdit->setText(QString(buffer).section("##",1,1));
//            ui->mysexLineEdit->setText(QString(buffer).section("##",2,2));

//        });
//    }
}

void homenew::on_pushButton_seal_clicked()
{
    QString program = "gnome-terminal";
    QString command = "python3 智能客服-小海豹.py";

    QStringList arguments;
    arguments << "-e" << command;

    QProcess *myProcess = new QProcess(this);
    qDebug() << "Command: " << program << arguments;
    //myProcess->start(program);
    myProcess->start(program, arguments);
}
