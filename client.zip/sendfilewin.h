#ifndef SENDFILEWIN_H
#define SENDFILEWIN_H
#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QFile>
#include <QTimer>
#include <QCloseEvent>


namespace Ui {
class sendfilewin;
}

class sendfilewin : public QWidget
{
    Q_OBJECT

public:
    explicit sendfilewin(QWidget *parent = nullptr);
    ~sendfilewin();
    //发送数据
    void sendData();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_selectfile_clicked();

    void on_pushButton_fswj_clicked();
protected:
    void closeEvent(QCloseEvent *event);

private:
    Ui::sendfilewin *ui;
        QTcpServer *tcpServer;
        QTcpSocket *tcpSocket;
        QFile file;
        QTimer timer;
        QString fileName;
        quint64 fileSize;
        quint64 sendSize;
};

#endif // SENDFILEWIN_H
