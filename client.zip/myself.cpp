#include "myself.h"
#include "ui_myself.h"
#include "homenew.h"
#include <userinfo.h>
// 从外部引入变量和类
extern userinfo user;
extern QString hostip;
extern int hosthost;

myself::myself(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::myself)
{
    ui->setupUi(this);
    tcpSocket = new QTcpSocket();
    ui->myusernameLineEdit->setText(user.name);
    ui->myipLineEdit->setText(user.ip);
    tcpSocket->abort();//取消已有链接
    tcpSocket->connectToHost(hostip, hosthost);//链接服务器
//    printf("myself::myself\n");

    if(!tcpSocket->waitForConnected(30000))
    {
        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
        this->close();
        user.islogin = false;
    }
    else
    {//服务器连接成功
//        printf("lianjiechenggong\n");
        QString loginmessage = QString("myself##%1").arg(user.name);
        tcpSocket->write(loginmessage.toUtf8());
        tcpSocket->flush();
        QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
        int port = tcpSocket->peerPort();
        QString str = QString("[%1:%2]").arg(ip).arg(port);
        qDebug() << str;

        // 当有数据可读时
        connect(tcpSocket,&QTcpSocket::readyRead,[=](){
            QByteArray buffer = tcpSocket->readAll();
//            printf("kedu");
            ui->myquestionLineEdit->setText(QString(buffer).section("##",0,0));
            ui->mybirthyearLineEdit->setText(QString(buffer).section("##",1,1));
            ui->mysexLineEdit->setText(QString(buffer).section("##",2,2));

        });
    }

}

myself::~myself()
{
    delete ui;
    delete tcpSocket;
}

void myself::on_myreturnpushButton_clicked()
{
    this->close();
}
