#ifndef FINDPWD_H
#define FINDPWD_H
#include <QTcpSocket>
#include <QDialog>

namespace Ui {
class findpwd;
}

class findpwd : public QDialog
{
    Q_OBJECT

public:
    explicit findpwd(QWidget *parent = nullptr);
    ~findpwd();

private slots:
    void on_pushButton_cancel_clicked();

    void on_PushButton_ok_clicked();

    void on_pushButton_find_clicked();

private:
    Ui::findpwd *ui;
    QTcpSocket *tcpSocket;
//    QString strr;
};

#endif // FINDPWD_H
