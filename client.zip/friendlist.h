#ifndef FRIENDLIST_H
#define FRIENDLIST_H

#include <QWidget>
#include <QTcpSocket>
namespace Ui {
class friendlist;
}

class friendlist : public QWidget
{
    Q_OBJECT

public:
    explicit friendlist(QWidget *parent = nullptr);
    QTimer *timer;
    ~friendlist();

private slots:
    void on_pushButton_quit_clicked();
    void Createdfriendlist();
    void on_pushButton_addpeople_clicked();

    void on_pushButton_startchat_clicked();

    void on_pushButton_deletepeople_clicked();

    void on_pushButton_fresh_clicked();

    void on_pushButton_clicked();
protected:
    void closeEvent(QCloseEvent *event);

private:
    Ui::friendlist *ui;
    QTcpSocket *tcpSocket;
};

#endif // FRIENDLIST_H
