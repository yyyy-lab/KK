#include "friendlist.h"
#include "ui_friendlist.h"
#include <userinfo.h>
#include <client.h>
#include <QtNetwork>
#include <chatdialog.h>
#include <qinputdialog.h>
#include <sendfiledialog.h>
#include <receivefiledialog.h>
#include "homenew.h"

extern userinfo user;
userinfo otheruser;
QList <QString> friendlist1;
QList <QString> friendiplist;
QList <QString> friendstatuelist;//1在线
QList <QString> friendsendmassagelist;
QList <QString> friendsendfilelist;
int id=-1;
QString hostip = "192.168.43.249";//server ip
int hosthost = 8888;

bool is_open_chatdialog;
int onlinenum = -1;
int listnum = -1;
int sendmassagenum = -1;
int sendfilenum = -1;

friendlist::friendlist(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::friendlist)
{
    ui->setupUi(this);
    timer = new QTimer();// 定时器，每隔500毫秒触发 Createdfriendlist() 函数
    timer->start(500);
    connect(timer,SIGNAL(timeout()),this,SLOT(Createdfriendlist()));
}

friendlist::~friendlist()
{
    timer->stop();
    id = ui->listWidget->currentRow();
    delete ui;
}

void friendlist::Createdfriendlist()
{
    if(is_open_chatdialog)
    {
        ui->pushButton_startchat->setEnabled(false);
    }
    else if(friendlist1.length()!=0 && !is_open_chatdialog)
    {
        ui->pushButton_startchat->setEnabled(true);
    }
    else if(friendlist1.length()==0 && !is_open_chatdialog)
    {
        ui->pushButton_startchat->setEnabled(false);
    }


    // 创建与服务器的TCP套接字并连接
        tcpSocket = new QTcpSocket();
        tcpSocket->abort();  // 取消已有连接
        tcpSocket->connectToHost(hostip, hosthost);  // 连接服务器
        if (!tcpSocket->waitForConnected(3000))
        {
            // 连接失败，显示警告消息并返回登录界面
            QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
            this->hide();
            user.islogin = false;
            client *cli = new client();
            cli->show();
        }
        else
        {
            // 连接成功，向服务器请求好友列表信息
            QString message = QString("getfriendlist##%1").arg(user.id);
            tcpSocket->write(message.toUtf8());
            tcpSocket->flush();

            // 监听服务器返回的数据
            connect(tcpSocket, &QTcpSocket::readyRead, [=]() {
                QByteArray buffer = tcpSocket->readAll();
                // 解析服务器返回的好友列表数据
                if (QString(buffer).section("##", 0, 0) == QString("getfriendlist_ok"))
                {
                    int newnum = QString(buffer).section("##", 1, 1).toInt();
                    int newonlinenum = QString(buffer).section("##", 2, 2).toInt();
                    int newsendmassagenum = QString(buffer).section("##", 3, 3).toInt();
                    int newsendfilenum = QString(buffer).section("##", 4, 4).toInt();

                    // 判断是否有更新，如果有更新则更新好友列表等信息
                    if (newsendmassagenum != sendmassagenum || sendfilenum != newsendfilenum ||
                        newonlinenum != onlinenum || onlinenum == -1 || sendmassagenum == -1 ||
                        listnum == -1 || newnum != listnum || sendfilenum == -1)
                    {
                        onlinenum = newonlinenum;
                        listnum = newnum;
                        sendfilenum = newsendfilenum;
                        sendmassagenum = newsendmassagenum;

                        // 清空好友相关信息
                        ui->listWidget->clear();
                        friendlist1.clear();
                        friendiplist.clear();
                        friendstatuelist.clear();
                        friendsendmassagelist.clear();
                        friendsendfilelist.clear();

                        // 解析每个好友的信息并添加到列表
                        for (int rownum = 0; rownum < newnum; rownum++)
                        {
                            QString friendname = QString(buffer).section("##", 5 + rownum * 5, 5 + rownum * 5);
                            QString friendstatue = QString(buffer).section("##", 6 + rownum * 5, 6 + rownum * 5);
                            QString friendip = QString(buffer).section("##", 7 + rownum * 5, 7 + rownum * 5);
                            QString friendsendmassage = QString(buffer).section("##", 8 + rownum * 5, 8 + rownum * 5);
                            QString friendsendfile = QString(buffer).section("##", 9 + rownum * 5, 9 + rownum * 5);

                            // 将好友信息添加到各个列表
                            friendlist1.append(friendname);
                            friendstatuelist.append(friendstatue);
                            friendiplist.append(friendip);
                            friendsendmassagelist.append(friendsendmassage);
                            friendsendfilelist.append(friendsendfile);

                            // 根据好友状态和消息情况生成显示文本
                            QString itemText;
                            if (friendstatue == '1')  // 好友在线
                            {
                                if (friendsendmassage == '1')
                                {
                                    if (friendsendfile == '1')
                                    {
                                        itemText = friendname + "(在线，想给您发文件，有新消息)";
                                    }
                                    else
                                    {
                                        itemText = friendname + "(在线，有新消息)";
                                    }
                                }
                                else
                                {
                                    if (friendsendfile == '1')
                                    {
                                        itemText = friendname + "(在线，想给您发文件)";
                                    }
                                    else
                                    {
                                        itemText = friendname + "(在线)";
                                    }
                                }
                            }
                            else  // 好友不在线
                            {
                                if (friendsendmassage == '1')
                                {
                                    itemText = friendname + "(不在线，有新消息)";
                                }
                                else
                                {
                                    itemText = friendname + "(不在线)";
                                }
                            }

                            // 将好友信息添加到列表控件
                            ui->listWidget->insertItem(rownum, tr(itemText.toUtf8()));
                        }

                        // 启用相关按钮
                        ui->pushButton_deletepeople->setEnabled(true);
                        if (!is_open_chatdialog)
                        {
                            ui->pushButton_startchat->setEnabled(true);
                        }
                    }
                }
                else if (QString(buffer).section("##", 0, 0) == QString("getfriendlist_error"))
                {
                    // 没有好友时的处理
                    if (listnum == -1 || listnum != 0)
                    {
                        listnum = 0;
                        ui->listWidget->clear();
                        ui->listWidget->insertItem(0, tr("您没有朋友"));
                    }
                    ui->pushButton_startchat->setEnabled(false);
                    ui->pushButton_deletepeople->setEnabled(false);
                }
            });
        }
        id = ui->listWidget->currentRow();
}
void friendlist::on_pushButton_startchat_clicked()
{
    if(ui->listWidget->currentRow()!=-1)
    {
        QString friendname = friendlist1.at(ui->listWidget->currentRow());
        id =ui->listWidget->currentRow();

        tcpSocket = new QTcpSocket();
        tcpSocket->abort();//取消已有链接
        tcpSocket->connectToHost(hostip, hosthost);//链接服务器
        if(!tcpSocket->waitForConnected(30000))
        {
            QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
            this->hide();
            user.islogin = false;
            client *cli = new client();
            cli->show();
        }
        else
        {//服务器连接成功
            QString message = QString("wantsendmessage##%1##%2").arg(user.id).arg(friendname);
            tcpSocket->write(message.toUtf8());
            tcpSocket->flush();

            connect(tcpSocket,&QTcpSocket::readyRead,[=](){
                QByteArray buffer = tcpSocket->readAll();
                if( QString(buffer).section("##",0,0) == QString("wantsendmessage_ok"))
                {//查有此人，可以发消息
                    otheruser.id = QString(buffer).section("##",1,1).toInt();
                    otheruser.name = friendname;
                    otheruser.ip = friendiplist.at(ui->listWidget->currentRow());
                    ui->pushButton_startchat->setEnabled(false);
                    chatdialog *cht = new chatdialog();
                    id =ui->listWidget->currentRow();
                    cht->show();
                }
            });
        }
    }
    else
    {
        QMessageBox::warning(this, "Warning!", "您未选择联系人", QMessageBox::Yes);
        this->show();
    }
}

void friendlist::on_pushButton_quit_clicked()
{
    // 关闭当前窗口，返回到zhu界面
    this->close();

}

void friendlist::on_pushButton_addpeople_clicked()
{
    bool ok;
    QString addfriendname = QInputDialog::getText(this,
                                                  tr("增添联系人"),
                                                  tr("请输入对方昵称"),
                                                  QLineEdit::Normal,0,&ok);
    if (ok && !addfriendname.isEmpty())
    {
        if(addfriendname != user.name)
        {
            tcpSocket = new QTcpSocket();
            tcpSocket->abort();//取消已有链接
            tcpSocket->connectToHost(hostip, hosthost);//链接服务器

            QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
            int port = tcpSocket->peerPort();
            QString str = QString("[%1:%2]").arg(ip).arg(port);
            qDebug() << str ;

            if(!tcpSocket->waitForConnected(30000))
            {
                QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
                this->close();
                user.islogin = false;
                client *cli = new client();
                cli->show();
            }
            else
            {//服务器连接成功
                QString message = QString("add_friend##%1##%2##%3##%4##%5").
                        arg(user.id).arg(addfriendname).
                        arg(ip).arg(port).arg(user.name);

                tcpSocket->write(message.toUtf8());
                tcpSocket->flush();

                connect(tcpSocket,&QTcpSocket::readyRead,[=](){
                    QByteArray buffer = tcpSocket->readAll();
                    qDebug() << QString(buffer);
                    if( QString(buffer).section("##",0,0) ==
                             QString("add_friend_error"))
                    {
                        QMessageBox::warning(this, "Warning!",
                                             "查无此人");
                    }
                });
            }
        }
        else
        {
            QMessageBox::warning(this, "Warning!", "不能添加自己");
        }
    }
}

void friendlist::on_pushButton_clicked()
{

    //连接服务，接受信息
    QTcpSocket *testSocket = new QTcpSocket(this);
    testSocket->abort();
    testSocket->connectToHost(hostip,hosthost);


//    QByteArray data = testSocket->readAll();
//    if (data.isEmpty()) {
//        qDebug() << "No data available for reading.";
//    } else {
//        qDebug() << "Received data from server:" << data;
//    }


    if(!testSocket->waitForConnected(30000))
    {
        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
        this->close();
    }
    else
    {//服务器连接成功
        QString message = QString("check##%1").arg(user.name);
        testSocket->write(message.toUtf8());
        testSocket->flush();

        // 当有数据可读时
        connect(testSocket,&QTcpSocket::readyRead,[=](){
            QByteArray buffer = testSocket->readAll();
            if(QString(buffer).section("##",0,0)==QString("no_check"))
            {
                QMessageBox::warning(this, "没有好友申请", "返回上一页");
            }
            else if(QString(buffer).section("##",0,0)==QString("check_success"))
            {
                QString friendname = QString(buffer).section("##",1,1);
                QString dlgTitle="验证消息";
                QString strInfo="您的好友："+friendname+"\n向您发起好友申请\n是否同意？";
                QMessageBox::StandardButton defaultBtn=QMessageBox::NoButton;
                QMessageBox::StandardButton result;
                result=QMessageBox::question(this, dlgTitle, strInfo,
                                             QMessageBox::Cancel|QMessageBox::Yes,
                                             defaultBtn);
                if (result==QMessageBox::Yes)
                {

                    QTcpSocket *resSocket = new QTcpSocket(this);
                    resSocket->abort();//取消已有链接
                    resSocket->connectToHost(hostip, hosthost);//链接服务器
                    if(!resSocket->waitForConnected())
                    {
                        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
                        this->close();
                        user.islogin = false;
                        client *cli = new client();
                        cli->show();
                    }
                    else
                    {//服务器连接成功
                        QString message = QString("add_friend_accept##%1##%2").
                                arg(user.name).arg(friendname);
                        resSocket->write(message.toUtf8());
                        resSocket->flush();
                        //加朋友
                        onlinenum = -1;
                        QMessageBox::warning(this, "提示", "添加成功");
                    }
                }
            }

        });
    }

}



void friendlist::on_pushButton_deletepeople_clicked()
{
    if(ui->listWidget->currentRow()!=-1)
    {
        QString friendname = friendlist1.at(ui->listWidget->currentRow());
        QString dlgTitle="提示";
        QString strInfo="您将删除好友："+friendname+"\n确定吗？";
        QMessageBox::StandardButton  defaultBtn=QMessageBox::NoButton;
        QMessageBox::StandardButton result;
        result=QMessageBox::question(this, dlgTitle, strInfo,QMessageBox::Cancel|QMessageBox::Yes,defaultBtn);
        if (result==QMessageBox::Yes)
        {

            tcpSocket = new QTcpSocket();
            tcpSocket->abort();//取消已有链接
            tcpSocket->connectToHost(hostip, hosthost);//链接服务器
            if(!tcpSocket->waitForConnected(30000))
            {
                QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
                this->close();
                user.islogin = false;
                client *cli = new client();
                cli->show();
            }
            else
            {//服务器连接成功
                QString message = QString("delete_friend##%1##%2").arg(user.id).arg(friendname);
                tcpSocket->write(message.toUtf8());
                tcpSocket->flush();

                connect(tcpSocket,&QTcpSocket::readyRead,[=](){
                    QByteArray buffer = tcpSocket->readAll();
                    if( QString(buffer).section("##",0,0) == QString("delete_friend_ok"))
                    {
                        Createdfriendlist();
                    }
                });
            }
        }
    }
    else
    {
        QMessageBox::warning(this, "Warning!", "您未选择联系人", QMessageBox::Yes);
    }
}

void friendlist::closeEvent(QCloseEvent *event)
{
    homenew * ho=new homenew();

    ho->show();
}


void friendlist::on_pushButton_fresh_clicked()
{
    onlinenum = -1;
    listnum = -1;
    sendmassagenum = -1;
    sendfilenum = -1;
}

