#include "client.h"
#include "ui_client.h"
#include <QtNetwork>
#include <QMessageBox>
#include <userinfo.h>
#include <homenew.h>
#include "findpwd.h"
// 在其他文件中定义的全局变量，用于保存用户信息和服务器信息
extern userinfo user;
extern QString hostip;
extern int hosthost;

// 构造函数
client::client(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::client)
{
    ui->setupUi(this);
    // 创建 QTcpSocket 对象
    tcpSocket = new QTcpSocket();
}

// 析构函数
client::~client()
{
    delete tcpSocket;
    delete ui;
}

// 登录按钮点击事件
void client::on_pushButton_login_clicked()
{
    // 检查用户名和密码是否都不为空
    if(ui->lineEdit_username->text()!="" && ui->lineEdit_pwd->text()!= "")
    {
        // 取消已有的连接，以便重新建立连接
        tcpSocket->abort();
        // 尝试与服务器建立连接
        tcpSocket->connectToHost(hostip, hosthost);
        // 获取服务器的 IP 地址和端口号
        QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
        int port = tcpSocket->peerPort();
        QString str = QString("[%1:%2]").arg(ip).arg(port);
        qDebug() << str ;

        // 等待连接成功，等待时间为 30000 毫秒（30 秒）
        if(!tcpSocket->waitForConnected(30000))
        {
            // 显示网络错误的警告框
            QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
        }
        else
        {
            // 服务器连接成功
            // 构造登录消息，格式为 "login##用户名##密码"
            QString loginmessage = QString("login##%1##%2").arg(ui->lineEdit_username->text()).arg(ui->lineEdit_pwd->text());
            // 发送登录消息到服务器
            tcpSocket->write(loginmessage.toUtf8());
            // 刷新缓冲区，确保消息被发送
            tcpSocket->flush();

            // 当有数据可读时，触发下面的 lambda 函数
            connect(tcpSocket, &QTcpSocket::readyRead, [=](){
                // 读取服务器返回的数据
                QByteArray buffer = tcpSocket->readAll();
                if(QString(buffer).section("##",0,0) == QString("login successed"))
                {
                    // 登录成功
                    // 从服务器返回的消息中获取用户 ID，保存用户信息，并关闭登录界面，显示主界面
                    user.id = QString(buffer).section("##",1,1).toInt();
                    user.name = ui->lineEdit_username->text();
                    user.islogin = true;
                    this->close();
                    homenew *hom = new homenew();
                    hom->show();
                }
                else if(QString(buffer).section("##",0,0) == QString("login error"))
                {
                    if(QString(buffer).section("##",1,1) == QString("no_user"))
                    {
                        // 用户不存在
                        QMessageBox::warning(this, "Warning!", "用户不存在", QMessageBox::Yes);
                        // 清空用户名和密码输入框，将光标聚焦在用户名输入框上
                        ui->lineEdit_username->clear();
                        ui->lineEdit_pwd->clear();
                        ui->lineEdit_username->setFocus();
                    }
                    else if(QString(buffer).section("##",1,1) == QString("errpwd"))
                    {
                        // 密码错误
                        QMessageBox::warning(this, "Warning!", "密码错误", QMessageBox::Yes);
                        // 清空密码输入框，将光标聚焦在密码输入框上
                        ui->lineEdit_pwd->clear();
                        ui->lineEdit_pwd->setFocus();
                    }
                }
            });
        }
    }
    else
    {
        // 用户名或密码为空，显示警告
        QMessageBox::warning(this, "Warning!", "用户名或密码不为空", QMessageBox::Yes);
        // 清空用户名和密码输入框，将光标聚焦在用户名输入框上
        ui->lineEdit_username->clear();
        ui->lineEdit_pwd->clear();
        ui->lineEdit_username->setFocus();
    }
}

// 注册按钮点击事件
void client::on_pushButton_register_clicked()
{
    // 关闭当前登录界面，显示注册对话框
    this->close();
    registerdialog *reg = new registerdialog();
    reg->show();
}

// 用户名输入框编辑完成事件
void client::on_lineEdit_username_editingFinished()
{
    // 恢复用户名标签的样式
    ui->label_username->setStyleSheet("color: rgb(0, 0, 0);font: 75 12pt Comic Sans MS;");
}

// 用户名输入框文本编辑事件
void client::on_lineEdit_username_textEdited(const QString &arg1)
{
    // 改变用户名标签的样式，用于提示用户正在编辑用户名
    ui->label_username->setStyleSheet("color: rgb(255, 85, 255);font: 75 12pt Comic Sans MS;");
}

// 密码输入框编辑完成事件
void client::on_lineEdit_pwd_editingFinished()
{
    // 恢复密码标签的样式
    ui->label_pwd->setStyleSheet("color: rgb(0, 0, 0);font: 75 12pt Comic Sans MS;");
}

// 密码输入框文本编辑事件
void client::on_lineEdit_pwd_textEdited(const QString &arg1)
{
    // 改变密码标签的样式，用于提示用户正在编辑密码
    ui->label_pwd->setStyleSheet("color: rgb(255, 85, 255);font: 75 12pt Comic Sans MS;");
}
void client::on_findpwdBtn_clicked()
{
    findpwd *find=new findpwd();
    find->show();
}
