#ifndef MYSELF_H
#define MYSELF_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QMessageBox>
#include <homenew.h>

namespace Ui {
class myself;
}

class myself : public QWidget
{
    Q_OBJECT

public:
    explicit myself(QWidget *parent = nullptr);
    ~myself();

private slots:
    void on_myreturnpushButton_clicked();

private:
    Ui::myself *ui;
    QTcpSocket *tcpSocket;

};

#endif // MYSELF_H
