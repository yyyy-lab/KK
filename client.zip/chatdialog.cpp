
#include "chatdialog.h"
#include "ui_chatdialog.h"
#include <userinfo.h>
#include <home.h>
#include <client.h>
#include "receivefilewin.h"
#include "friendlist.h"
#include <QFileDialog>
#include "ui_friendlist.h"
#include "sendfilewin.h"
#include <QVBoxLayout>
#include <QScreen>
#include <QPixmap>
#include <QBuffer>
#include <QByteArray>

#include <QPixmap>
#include <QLabel>


extern userinfo user;
extern bool is_open_chatdialog;
extern userinfo otheruser;
extern QString hostip;
extern int hosthost;
extern QList <QString> friendlist1;
extern QList <QString> friendiplist;
extern QList <QString> friendsendfilelist;
extern int id;
QList <QString> chathistorylist;


chatdialog::chatdialog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::chatdialog)
{
    ui->setupUi(this);
    otheruser.ip = friendiplist.at(id);
    ui->label_title->setText("您正在与"+otheruser.name+
                             "进行对话（IP地址："+otheruser.ip+"）");
    is_open_chatdialog = true;
    tcpSocket = new QTcpSocket();
    timer = new QTimer();
    qDebug()<<otheruser.id<<otheruser.name;
    connect(timer,SIGNAL(timeout()),this,SLOT(getchathistory()));
    timer->start(500);
}

chatdialog::~chatdialog()
{
    is_open_chatdialog = false;
    timer->stop();
    delete ui;
}

void chatdialog::on_pushButton_send_clicked()
{//发送消息
    if(ui->lineEdit_sendmessage->text()!="")
    {
        tcpSocket->abort();//取消已有链接
        tcpSocket->connectToHost(hostip, hosthost);//链接服务器
        QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
        int port = tcpSocket->peerPort();
        QString str = QString("[%1:%2]").arg(ip).arg(port);
        qDebug() << str ;
        if(!tcpSocket->waitForConnected(30000))
        {
            QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
            this->close();
            user.islogin = false;
            client *cli = new client();
            cli->show();
        }
        else
        {//服务器连接成功
            //第一个是时间，第二个发送的ID，第三个是接受的ID，第四个是内容
            QString nowstr = QDateTime::currentDateTime().currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
            QString message = QString("chat_send##%1##%2##%3##%4").arg(nowstr).arg(user.id).arg(otheruser.id).arg(ui->lineEdit_sendmessage->text());
            tcpSocket->write(message.toUtf8());
            tcpSocket->flush();
            ui->lineEdit_sendmessage->clear();
        }
    }
    else
    {//空消息
        QMessageBox::warning(this, "Warning!", "不能发送空消息", QMessageBox::Yes);
    }
}

void chatdialog::on_pushButton_clicked()
{
    qDebug()<<is_open_chatdialog;

    is_open_chatdialog = false;
    qDebug()<<is_open_chatdialog;
    this->close();
    timer->stop();
}

void chatdialog::getchathistory()
{
    tcpSocket->abort();//取消已有链接
    tcpSocket->connectToHost(hostip, hosthost);//链接服务器

    if(!tcpSocket->waitForConnected(30000))
    {
        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
        this->close();
    }
    else
    {//服务器连接成功
        QString message = QString("chat_history##%1##%2").arg(user.id).arg(otheruser.id);
        tcpSocket->write(message.toUtf8());
        tcpSocket->flush();
        connect(tcpSocket,&QTcpSocket::readyRead,[=](){
            QByteArray buffer = tcpSocket->readAll();
            if(QString(buffer).section("##",0,0)==QString("chat_history_ok"))
            {
                QString chatshow = "";
                int num = QString(buffer).section("##",1,1).toInt();
                for(int rownum = 0;rownum < num ;rownum++)
                {
                    QDateTime time = QDateTime::fromString( QString(buffer).section("##",rownum*3+2,rownum*3+2),"yyyy-MM-dd hh:mm:ss.zzz");
                    qDebug()<<time.toString();
                    QString timeshow = time.toString("MM-dd hh:mm:ss");
                    qDebug()<<timeshow;
                    QString idshow = "";
                    QString sssss = QString(buffer).section("##",rownum*3+4,rownum*3+4);
                    qDebug()<<sssss;
                    if(QString(buffer).section("##",rownum*3+3,rownum*3+3).toInt()==user.id)
                                        {//我自己发送的消息
                                            idshow = " 我：";
                                            // 设置文本格式，使自己的消息显示在右侧
                                            if(sssss != "SHAKE")
                                                chatshow = QString("<p align='right'><span style='color: blue;'>(%1)%2</span><br>%3</p>").arg(timeshow).arg(idshow).arg(QString(buffer).section("##", rownum * 3 + 4, rownum * 3 + 4)) + chatshow;
                                        }

                                        else
                                        {
                                            idshow =" "+ otheruser.name + "：";
                                            chathistorylist.prepend(sssss);
                                            // 设置文本格式，使对方的消息显示在左侧
                                            if(sssss != "SHAKE")
                                                chatshow = QString("<p align='left'><span style='color: green;'>(%1)%2</span><br>%3</p>").arg(timeshow).arg(idshow).arg(QString(buffer).section("##", rownum * 3 + 4, rownum * 3 + 4)) + chatshow;
                                        }
               }




                                    ui->textBrowser_chat->setHtml(chatshow);


                                    QTextCursor cursor=ui->textBrowser_chat->textCursor();
                                    cursor.movePosition(QTextCursor::End);
                                    ui->textBrowser_chat->setTextCursor(cursor);


            }
            else if(QString(buffer).section("##",0,0)==QString("chat_history_error"))
            {
                ui->textBrowser_chat->setText("无消息记录");
            }
            if(chathistorylist.empty())
            {
                qDebug()<<"kongkongkong";

            }
            else if(chathistorylist.at(0) == "SHAKE")
          //else if(chathistorylist.at(chathistorylist.length()-1) == "SHAKE")
                receive_shake();

            chathistorylist.clear();
        });
    }
}




void chatdialog::on_pushButton_receivefile_clicked()
{
    // 获取选择的好友昵称和文件发送状态
            QString friendname = friendlist1.at(id);

            // 检查是否有文件要接收
            if (friendsendfilelist.at(id) == "1")
            {
                // 设置otheruser信息并弹出文件接收对话框
                otheruser.name = friendname;
                //otheruser.ip = friendiplist.at(id);
                qDebug()<<otheruser.ip<< otheruser.id;
                // 弹出文件接收对话框
                receivefilewin *rf = new receivefilewin();
                rf->show();
            }
            else
            {
                // 没有文件要接收时显示警告消息
                QMessageBox::warning(this, "Warning!", "该联系人未给您发送文件", QMessageBox::Yes);
            }



}

void chatdialog::on_pushButton_sendfile_clicked()
{
        // 创建与服务器的TCP套接字并连接
        tcpSocket = new QTcpSocket();
        tcpSocket->abort();  // 取消已有连接
        tcpSocket->connectToHost(hostip, hosthost);  // 连接服务器
        if (!tcpSocket->waitForConnected(30000))
                    {
                        // 连接失败，显示警告消息并返回登录界面
                        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
                        this->hide();
                        user.islogin = false;
                        client *cli = new client();
                        cli->show();
                    }
        else
                    {
                        // 连接成功，向服务器请求发送文件
                        QString message = QString("want_send_file##%1##%2").arg(user.id).arg(otheruser.name);
                        tcpSocket->write(message.toUtf8());
                        tcpSocket->flush();
                        this->hide();
                    }
        sendfilewin *sfw = new sendfilewin();
        sfw->show();

}
// 窗口关闭事件
void chatdialog::closeEvent(QCloseEvent *event)
{
   // 回到主界面并发送文件接收成功信息

    is_open_chatdialog = false;
    friendlist *fl = new friendlist();
    fl->show();
    timer->stop();

}

void chatdialog::on_pushButton_shake_clicked()
{
    tcpSocket->abort();//取消已有链接
    tcpSocket->connectToHost(hostip, hosthost);//链接服务器
    QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
    int port = tcpSocket->peerPort();
    QString str = QString("[%1:%2]").arg(ip).arg(port);
    qDebug() << str ;
    if(!tcpSocket->waitForConnected(30000))
    {
        QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
        this->close();
        user.islogin = false;
        client *cli = new client();
        cli->show();
    }
    else
    {//服务器连接成功
        //第一个是时间，第二个发送的ID，第三个是接受的ID，第四个是内容
        QString nowstr = QDateTime::currentDateTime().currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz");
        QString message = QString("chat_send##%1##%2##%3##%4").arg(nowstr).arg(user.id).arg(otheruser.id).arg(QString("SHAKE"));
        tcpSocket->write(message.toUtf8());
        tcpSocket->flush();
        ui->lineEdit_sendmessage->clear();
    }

}
void chatdialog::receive_shake()
{
    // 触发抖动动画
    QPropertyAnimation* animation = new QPropertyAnimation(this, "pos");
    animation->setDuration(100);
    animation->setLoopCount(10);
    // 设置起始值和结束值，让窗口在抖动过程中移动
     QPoint startPos = this->pos();
     QPoint endPos = startPos + QPoint(10, 0); // 这里可以根据需要调整偏移量
     QPoint endPos1 = startPos + QPoint(0, 10); // 这里可以根据需要调整偏移量
     animation->setStartValue(startPos);
    animation->setEndValue(endPos);
    animation->setEndValue(endPos1);
    animation->start(QAbstractAnimation::DeleteWhenStopped);

}


void chatdialog::on_pushButton_screenshot_clicked()
{
    // Get the geometry of the chat widget
    QRect chatGeometry = ui->textBrowser_chat->geometry();

    // Calculate the position of the chat widget relative to the screen
    QPoint chatWidgetPos = ui->textBrowser_chat->mapToGlobal(QPoint(0, 0));

    // Capture the screen screenshot, limited to the chat widget's area
    QPixmap screenshot = QGuiApplication::primaryScreen()->grabWindow(0, chatWidgetPos.x(), chatWidgetPos.y(), chatGeometry.width(), chatGeometry.height());

    QLabel *label = new QLabel();
    label->setPixmap(screenshot);

    QMainWindow *screenshotWindow = new QMainWindow();
    screenshotWindow->setCentralWidget(label);
    screenshotWindow->show();

    QPushButton *zoomInButton = new QPushButton("Zoom In");
    QPushButton *zoomOutButton = new QPushButton("Zoom Out");
    QPushButton *cropButton = new QPushButton("Crop");

    QVBoxLayout *layout = new QVBoxLayout();
    layout->addWidget(label);
    layout->addWidget(zoomInButton);
    layout->addWidget(zoomOutButton);
    layout->addWidget(cropButton);

    QWidget *centralWidget = new QWidget();
    centralWidget->setLayout(layout);
    screenshotWindow->setCentralWidget(centralWidget);

    connect(zoomInButton, &QPushButton::clicked, [&]() {
        label->setPixmap(label->pixmap()->scaled(label->pixmap()->size() * 1.5));
    });

    connect(zoomOutButton, &QPushButton::clicked, [&]() {
        label->setPixmap(label->pixmap()->scaled(label->pixmap()->size() * 0.75));
    });

    connect(cropButton, &QPushButton::clicked, [&]() {
        // Implement your cropping logic here
        // You can create a cropping dialog or handle cropping directly on the label's pixmap
    });
}

