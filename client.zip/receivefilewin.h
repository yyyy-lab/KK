#ifndef RECEIVEFILEWIN_H
#define RECEIVEFILEWIN_H

#include <QWidget>
#include <QTcpSocket>
#include <QFile>
#include <QCloseEvent>


namespace Ui {
class receivefilewin;
}

class receivefilewin : public QWidget
{
    Q_OBJECT

public:
    explicit receivefilewin(QWidget *parent = nullptr);
    ~receivefilewin();
protected:
    void closeEvent(QCloseEvent *event);

private:
    Ui::receivefilewin *ui;
    QTcpSocket *tcpSocket;
    QFile file;
    QString fileName;
    quint64 fileSize;
    quint64 receiveSize;
    bool isStart;

    QString ip;
    qint16 port;

};

#endif // RECEIVEFILEWIN_H
