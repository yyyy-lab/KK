#include "findpwd.h"
#include "ui_findpwd.h"
#include <QApplication>
#include "client.h"
#include "ui_client.h"
#include <QtNetwork>
#include <QMessageBox>
#include <userinfo.h>

extern userinfo user;
extern QString hostip;
extern int hosthost;

findpwd::findpwd(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::findpwd)
{
    ui->setupUi(this);
    printf("construct\n");
    //创建QTcpSocket对象
    tcpSocket =new QTcpSocket();
}

findpwd::~findpwd()
{
    delete tcpSocket;
    delete ui;
}

void findpwd::on_pushButton_cancel_clicked()
{
    this->close();
}

QString strr;

void findpwd::on_PushButton_ok_clicked()
{
    printf("ok");
    if(ui->lineEdit_fusername->text()!="")
    {
        printf("bukong");
        tcpSocket->connectToHost(hostip,hosthost);
        printf("host");
        // 获取服务器的 IP 地址和端口号
        QString ip = tcpSocket->peerAddress().toString().section(":",3,3);
        int port = tcpSocket->peerPort();
        QString str = QString("[%1:%2]").arg(ip).arg(port);
        qDebug() << str ;
        printf("str\n");
        // 等待连接成功，等待时间为 30000 毫秒（30 秒）
        if(!tcpSocket->waitForConnected(30000))
        {
            // 显示网络错误的警告框
            QMessageBox::warning(this, "Warning!", "网络错误", QMessageBox::Yes);
            printf("11\n");
        }
        else
        {
            printf("22\n");
            // 构造找回密码消息，格式为 "find##用户名"
            QString findmessage = QString("find##%1").arg(ui->lineEdit_fusername->text());
            printf("33\n");
            // 发送登录消息到服务器
            tcpSocket->write(findmessage.toUtf8());
            // 刷新缓冲区，确保消息被发送
            tcpSocket->flush();
            // 当有数据可读时
            printf("44\n");

            connect(tcpSocket,&QTcpSocket::readyRead,[=](){
                QByteArray buffer = tcpSocket->readAll();
                printf("55\n");
                strr=QString(buffer);
                if(QString(buffer).section("##",0,0)==QString("find_error"))
                {//出错
                    QMessageBox::warning(this, "Warning!", "用户名不为空", QMessageBox::Yes);
                    ui->lineEdit_fusername->clear();
                    ui->lineEdit_fusername->setFocus();
                    printf("1");
                }
                else
                {printf("2");
                    ui->lineEdit_fquestion->setText(QString(buffer).section("##",0,0));
                    if(ui->lineEdit_fanswer->text()==QString(buffer).section("##",1,1))
                    {
                        ui->lineEdit_fpwd->setText(QString(buffer).section("##",2,2));
                    }
                }
            });

        }

    }
    else
    {
        // 用户名为空，显示警告
        QMessageBox::warning(this, "Warning!", "用户名不为空", QMessageBox::Yes);
        // 清空用户名和密码输入框，将光标聚焦在用户名输入框上
        ui->lineEdit_fusername->clear();
    }
}

void findpwd::on_pushButton_find_clicked()
{
    if(ui->lineEdit_fanswer->text()==strr.section("##",1,1))
    {
        ui->lineEdit_fpwd->setText(strr.section("##",2,2));
    }
    else
    {
        QMessageBox::warning(this, "Warning!", "密保问题回答错误", QMessageBox::Yes);
        ui->lineEdit_fanswer->clear();
        ui->lineEdit_fanswer->setFocus();
    }
}
