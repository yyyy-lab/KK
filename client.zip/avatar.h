#ifndef AVATAR_H
#define AVATAR_H

#include <QDialog>
#include <QWidget>
#include <QTcpSocket>
#include <QMouseEvent>
#include <QTcpServer>

namespace Ui {
class avatar;
}

class avatar : public QDialog
{
    Q_OBJECT

public:
    explicit avatar(QWidget *parent = nullptr);
    ~avatar();

private slots:
    void on_pushButton_clicked();
    
    void recvMsg();
    
    void on_pushButton_2_clicked();
    
    void on_cancelButton_clicked();
    
protected:
    void mousePressEvent(QMouseEvent *event); //鼠标按下事件
    void mouseMoveEvent(QMouseEvent *event);  //鼠标移动事件
    
private:
    Ui::avatar *ui;
    QTcpSocket *tcpSocket;
    QPoint m_point;
};

#endif // AVATAR_H
